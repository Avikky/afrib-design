
<?php $__env->startSection('pageTitle', 'Settings'); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container">
    
      <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success alert-block">
          <button type="button" class="close" data-dismiss="alert">×</button> 
          <strong><?php echo e($message); ?></strong>
        </div>
      <?php endif; ?>

      <?php if($message = Session::get('error')): ?>
      <div class="alert alert-danger alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button> 
        <strong><?php echo e($message); ?></strong>
      </div>
    <?php endif; ?>

      <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
          <strong>Error!</strong>
          <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      <?php endif; ?>
    <div class="row">
      <div class="col-md-3"></div>
      <div class="col-md-6">
        <div class="card mt-3">
          <div class="card-body">
            <div class="card">
                <?php if(Auth::user()->image != null): ?>
                    <div class="d-flex justify-content-center">
                        <img width="160px" height="160px" class="img-circle" src="<?php echo e('/storage/'.Auth::user()->image); ?>" alt="Card image cap">
                    </div>
                <?php else: ?>
                    <div class="d-flex justify-content-center">
                        <img class="img-circle" width="170px" height="170px" src="https://img.freepik.com/free-vector/businessman-character-avatar-isolated_24877-60111.jpg" alt="User Avatar">
                    </div>
                <?php endif; ?>
                <h3 class="text-center"><?php echo e(Auth::user()->name); ?></h3>
                <br><br>

                <div class="card-body">
                    <form action="<?php echo e(route('update.password')); ?>" enctype="multipart/form-data" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="name">Old Password</label>                     
                            <input class="form-control" type="password" name="oldpwd">
                        </div>
                        <div class="form-group">
                            <label for="name">New Password</label>                     
                            <input class="form-control" type="password" name="newpwd">
                        </div>
                        <div class="form-group">
                            <label for="name">Confirm Password</label>                     
                            <input class="form-control" type="password" name="cpwd">
                        </div>
                        <div class="d-flex justify-content-center">
                            <button type="submit" class="btn btn-primary">Save Changes</button>
                        </div>
                    </form>
                </div>
              </div>
          </div>
        </div><!-- /.box -->
      </div>
      <div class="col-md-3"></div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\afrib-design\resources\views/admin/settings.blade.php ENDPATH**/ ?>