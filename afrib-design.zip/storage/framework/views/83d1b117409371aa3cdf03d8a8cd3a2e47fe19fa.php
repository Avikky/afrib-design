<?php $__env->startSection('pageTitle', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
	<div class="mb-sm-4 py-4 px-3 d-flex flex-wrap align-items-center text-head">
		<h2 class="font-w600 mb-2 me-auto">Dashboard</h2>
	</div>
	<div>
		<h3 class="text-center">
			Hi <?php echo e(Auth::user()->name); ?> Welcome to Afrib Design Travel Stories</h3><br>
		<p class="text-center">Become a travel writer today..!</p>
	</div>	
	<div class="d-flex justify-content-center align-items-center">
		<div class="col-4">
			<div class="card">
				<div class="card-body">
					<div class="me-3 text-center">
						Total Stories written by you
					</div>
					<div>
						<h2 class="text-center"><?php echo e(count(\App\Models\Story::where('user_id', Auth::id())->get())); ?></h2>
						
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\afrib-design\resources\views/account/dashboard.blade.php ENDPATH**/ ?>