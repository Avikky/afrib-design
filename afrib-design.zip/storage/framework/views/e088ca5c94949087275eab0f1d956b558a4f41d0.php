<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'btn btn-dark text-white'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\xampp\htdocs\coinab\resources\views/components/button.blade.php ENDPATH**/ ?>