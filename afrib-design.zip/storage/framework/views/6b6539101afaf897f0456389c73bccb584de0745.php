
<?php $__env->startSection('pageTitle', 'Profile'); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container">
    
      <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success alert-block">
          <button type="button" class="close" data-dismiss="alert">×</button> 
          <strong><?php echo e($message); ?></strong>
        </div>
      <?php endif; ?>

      <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
          <strong>Error!</strong>
          <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      <?php endif; ?>
    <div class="row">
      <div class="col-md-3"></div>
      <div class="col-md-6">
        <div class="card mt-3">
          <div class="card-body">
            <div class="card">
                <?php if(Auth::user()->image != null): ?>
                    <div class="d-flex justify-content-center">
                        <img width="160px" height="160px" class="img-circle" src="<?php echo e('/storage/'.Auth::user()->image); ?>" alt="Card image cap">
                    </div>
                <?php else: ?>
                    <div class="d-flex justify-content-center">
                        <img class="img-circle" width="170px" height="170px" src="https://img.freepik.com/free-vector/businessman-character-avatar-isolated_24877-60111.jpg" alt="User Avatar">
                    </div>
                <?php endif; ?>
                <h3 class="text-center"><?php echo e(Auth::user()->name); ?></h3>
                <br><br>

                <div class="card-body">
                    <form action="<?php echo e(route('update.profile', ['id' => Auth::id()])); ?>" enctype="multipart/form-data" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="name">Name</label>                     
                            <input class="form-control" value="<?php echo e(Auth::user()->name); ?>" type="text" name="name">
                        </div> 
                        <div class="form-group">
                            <label for="name">email</label>                     
                            <input class="form-control" value="<?php echo e(Auth::user()->email); ?>" type="text" name="email">
                        </div>
                        <?php if(Auth::user()->role != 1): ?>
                            <div class="form-group">
                                <label for="name">Special login link</label>                     
                                <input readonly class="form-control" value="<?php echo e(Auth::user()->link); ?>" type="text">
                            </div>
                        <?php endif; ?>
                        <div class="form-group">
                            <label for="profile_pic">Change profile picture</label>
                            <input class="form-control-file" type="file" name="profile_pic" >  
                        </div>
                        <div class="d-flex justify-content-center">
                            <button type="submit" class="btn btn-primary">Save Changes</button>
                        </div>
                    </form>
                </div>
              </div>
          </div>
        </div><!-- /.box -->
      </div>
      <div class="col-md-3"></div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\afrib-design\resources\views/account/profile.blade.php ENDPATH**/ ?>