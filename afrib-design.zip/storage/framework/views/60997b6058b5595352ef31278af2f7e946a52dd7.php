
<?php $__env->startSection('pageTitle', 'View Story'); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container">
    
      <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success alert-block">
          <button type="button" class="close" data-dismiss="alert">×</button> 
          <strong><?php echo e($message); ?></strong>
        </div>
      <?php endif; ?>

      <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
          <strong>Error!</strong>
          <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      <?php endif; ?>
    <div class="row">
      <div class="col-md-3">
        <div class="card mt-3">
            <div class="card-header">
                <h5 class="card-title">All Category</h5>
                <small class="text-muted">Total number of story in a category on the right</small>
            </div>

            <div class="card-body">
                <div class="list-group">
                    <a href="<?php echo e(route('all.story')); ?>" class="list-group-item list-group-item-action active">
                        All Categories
                    </a>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('all.story', ['category'=>$category->id])); ?>" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                            <?php echo e($category->name); ?>

                            <span class="badge badge-primary badge-pill"><?php echo e(count(\App\Models\Story::where('category_id', $category->id)->get())); ?></span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="card mt-3">
            <div class="card-header">
                <h5 class="card-title">All Locations</h5>
                <small class="text-muted">See stories about a location</small>
            </div>

            <div class="card-body">
                <div class="list-group">
                    <a href="<?php echo e(route('all.story')); ?>" class="list-group-item list-group-item-action active">
                        All Locations
                    </a>
                    <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('all.story', ['location'=>$location->id])); ?>" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                            <?php echo e($location->country); ?>

                            <span class="badge badge-primary badge-pill"><?php echo e(count(\App\Models\Story::where('category_id', $location->id)->get())); ?></span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
      </div>
        <div class="col-md-9">
            <div class="row">
                <?php $__currentLoopData = $stories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 card my-3" style="height: 220px; background-image: url('<?php echo e('storage/'.$story->image); ?>');background-position: center;background-repeat: no-repeat; background-size: cover;">

                        <div class="d-flex justify-content-center align-items-end card-body">
                            <div class="card-title px-4" style="width: 70%; height: 190px; background-color: rgb(0,0,0, 0.5); color: #fff; border-radius: 10px;" >
                                <h3 class="text-center"><?php echo e($story->title); ?></h3>
                                <p>
                                    <?php echo html_entity_decode(substr(strip_tags($story->story) , 0, 50)); ?>

                                </p>
                                <p class="d-flex justify-content-center">
                                    <a class="btn btn-primary btn-sm" href="<?php echo e(route('view.story', ['slug' => $story->slug])); ?>">Read story</a>
                                </p>
                                <br>
                            </div>
                        </div>
        
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.live', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\afrib-design\resources\views/allstory.blade.php ENDPATH**/ ?>