
<?php $__env->startSection('pageTitle', 'Category'); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container">
    
      <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success alert-block">
          <button type="button" class="close" data-dismiss="alert">×</button> 
          <strong><?php echo e($message); ?></strong>
        </div>
      <?php endif; ?>

      <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
          <strong>Error!</strong>
          <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      <?php endif; ?>
    <div class="row">
      <div class="col-md-4">
        <div class="card mt-3">
          <div class="card-header">
            <h3 class="card-title">All Category</h3><br>
            <small class="text-muted">Total number of story in a category on the right</small>
          </div>

          <div class="card-body">
            <ul class="list-group">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <?php echo e($category->name); ?>

                        <span class="badge badge-primary badge-pill"><?php echo e(count(\App\Models\Story::where('category_id', $category->id)->get())); ?></span>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
          </div>
        </div>
      </div>
      <div class="col-md-8">
        <div class="card mt-3">
          <div class="card-body">
            <div class="card">
                <img class="card-img-top" src="<?php echo e('/storage/'.$story->image); ?>" alt="Card image cap">
                <div class="card-body">
                  <h3 class="card-title text-center"><?php echo e($story->title); ?></h3>
                  <br>
                  <div class="card-footer row">
                    <small class="pr-2"><strong>Category:</strong> <?php echo e($story->cat_name); ?></small>
                    <small class="pr-2"><strong>Date:</strong> <i><?php echo e($story->created_at); ?></i></small>
                    <small class="pr-2"><strong>Author</strong> </small>
                    <small class="pr-2">
                      <strong>status:</strong>
                      <?php if($story->status == 0): ?>
                      <span class="badge badge-warning">Pending till review</span>
                      <?php elseif($story->status == 1): ?>
                      <span class="badge badge-primary">Published</span>
                      <?php elseif($story->status == 2): ?>
                        <span class="badge badge-danger">Rejected</span>
                      <?php endif; ?>
                      
                    </small>
                    <small><strong>Location:</strong> <i class="">Russia</i></small>
                  </div>
                  <hr>
                  <p class="card-text">
                      <?php echo $story->story; ?>

                  </p>
                  
                </div>
              </div>
          </div>
        </div><!-- /.box -->
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\afrib-design\resources\views/account/preview.blade.php ENDPATH**/ ?>