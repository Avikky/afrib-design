
<?php $__env->startSection('pageTitle', 'All Stories'); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container">
    <?php if($message = Session::get('success')): ?>
      <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button> 
        <strong><?php echo e($message); ?></strong>
      </div>
    <?php endif; ?>

    <?php if(count($errors) > 0): ?>
      <div class="alert alert-danger">
        <strong>Error!</strong>
        <ul>
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    <?php endif; ?>
    <div class="row">
      <div class="col-lg-12">
        <div class="card mt-3">
          <div class="card-header row">
            <h3 class="card-title col-md-10">All My Stories</h3>
            <button data-target="#modal-lg" data-toggle="modal" class="col-md-2 btn btn-sm btn-primary">Add new Story</button>
          </div>

          <div class="modal fade" id="modal-lg" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                  <div class="modal-header">
                    <h4 class="modal-title">Share your story to the world</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                    </button>
                    </div>
                    <div class="modal-body">
                      <form method="post" class="profile-wrapper" enctype="multipart/form-data" action="<?php echo e(route('create.story')); ?>" >
                        <?php echo csrf_field(); ?>
                         
                            <div class="form-group">
                               <label for="fname">Story Title</label>                     
                               <input class="form-control" type="text" name="title" required autofocus placeholder="Super Hikcing Experience">
                           </div> 
                          <div class="form-group">
                            <label for="fname">Story Category</label> 
                            <select class="form-control" name="category" id="">
                              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          </div>
                          <div class="form-group">
                            <label for="fname">Select Location</label> 
                            <select class="form-control" name="location" id="">
                              <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($location->id); ?>"><?php echo e($location->country); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          </div>
                         <div class="form-group">
                           <label for="fname">Main Story</label>
                           <textarea  class="form-control" id="storyEditor" rows="50" cols="40" name="story">
                           </textarea>
                           <script>
                               // Replace the <textarea id="editor1"> with a CKEditor
                               // instance, using default configuration.
                               CKEDITOR.replace( 'storyEditor' );
                           </script>   
                         </div>
       
                          <div class="form-group">
                             <label for="fname">Featured Image</label>
                             <input class="form-control" type="file" name="featured_image" required autofocus>  
                         </div>                            
                 
                    </div>
                    <div class="modal-footer justify-content-between">
                      <input hidden type="text" name="is_draft" value="1">
                      <button type="button" class="btn btn-default" data-dismiss="modal">close</button>
                      <button type="submit" class="btn btn-primary">Publish</button>
                  </div>

                </form>
            </div>
            
            </div>
            
          </div>

       
          <div class="card-body">
            <div class="row">
              <?php $__empty_1 = true; $__currentLoopData = $stories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-4">
                  <div class="card card-widget widget-user shadow-lg">
                    <div class="widget-user-header text-white" style="background: url('<?php echo e('/storage/'.$story->image); ?>') center center;">
                    
                    </div>
                    <div class="widget-user-image">
                      <?php if(Auth::user()->image == null): ?>
                        <img class="img-circle" src="https://img.freepik.com/free-vector/businessman-character-avatar-isolated_24877-60111.jpg" alt="User Avatar">
                      <?php else: ?>
                        <img class="img-circle" src="<?php echo e('/storage/'.Auth::user()->image); ?>" alt="User Avatar">
                      <?php endif; ?>
                      
                    </div>
                    
                    <div class="card-footer">
                      <div class="row">
                        <div class="justify-content-center">
                          <h4 class="widget-user-desc text-center"><?php echo e($story->title); ?></h4> 
                        </div>
                        <div class="row">
                          <p class="row px-3">
                            <?php echo e(substr(strip_tags($story->story) , 0, 100)); ?> 
                          </p>
                          <div class="row px-3">
                            <small class="pr-4"><strong>Category:</strong> <?php echo e($story->cat_name); ?></small>
                            <small><strong>Date:</strong> <i><?php echo e($story->created_at); ?></i></small>

                            <small class="pr-4">
                              <strong>status:</strong>
                              <?php if($story->status == 0): ?>
                              <span class="badge badge-warning">Pending till review</span>
                              <?php elseif($story->status == 1): ?>
                              <span class="badge badge-primary">Published</span>
                              <?php elseif($story->status == 2): ?>
                                <span class="badge badge-danger">Rejected</span>
                              <?php endif; ?>
                              
                            </small>
                            <small><strong>Location:</strong> <i class=""><?php echo e($story->loca_country); ?></i></small>
                          </div>
                        </div>
                      </div>
                      <hr>
                      <div class="row gx-3">
                        <a href="<?php echo e(route('show.story', ['slug' => $story->slug])); ?>" class="btn btn-xs btn-primary mx-2 px-2">Preview</a>
                        <?php if(Auth::user()->role == 1): ?>
                          <a href="" data-target="#editor<?php echo e($story->id); ?>" data-toggle="modal" class="btn btn-xs btn-warning mx-2 px-2">Take Action</a>
                        <?php else: ?>
                          <a href="" data-target="#editor<?php echo e($story->id); ?>" data-toggle="modal" class="btn btn-xs btn-default mx-2 px-2">Edit</a>
                        <?php endif; ?>
                        <a href="" class="btn btn-xs btn-danger mx-2 px-2">Delete</a>
                      </div>
                    </div>
                  </div>

                  <div class="modal fade" id="editor<?php echo e($story->id); ?>" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h4 class="modal-title">Share your story to the world</h4>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">×</span>
                          </button>
                        </div>
                        <div class="modal-body">
                          <?php if(Auth::user()->role == 1): ?>
                            <div class="row">
                              <div class="col-md-6">
                                <div class="d-flex justify-content-center">
                                  <form method="Post" class="profile-wrapper" action="<?php echo e(route('approve.story', ['id' => $story->id] )); ?>" >
                                    <?php echo e(csrf_field()); ?>

                                      
                                    <div class="modal-footer justify-content-between">
                                      <input hidden type="text" name="approve" value="1">
                                      <button type="submit" class="btn btn-success">Approve story</button>
                                    </div>
            
                                  </form>
                                </div>
                              </div>
                              <div class="col-md-6">
                                <div class="d-flex justify-content-center">
                                  <form method="post" class="profile-wrapper" enctype="multipart/form-data" action="<?php echo e(route('reject.story', ['id'=> $story->id] )); ?>" >
                                    <?php echo e(csrf_field()); ?>

                                      
                                    <div class="modal-footer justify-content-between">
                                      <input hidden type="text" name="reject" value="2">
                                      <button type="submit" class="btn btn-danger">Reject story</button>
                                    </div>
            
                                  </form>
                                </div>
                              </div>
                            </div>
                          <?php else: ?>
                            <form method="post" class="profile-wrapper" enctype="multipart/form-data" action="<?php echo e(route('edit.story', ['id'=> $story->id] )); ?>" >
                              <?php echo e(csrf_field()); ?>


                                <div class="form-group">
                                    <label for="fname">Story Title</label>                     
                                    <input class="form-control" value="<?php echo e($story->title); ?>" type="text" name="title" required autofocus placeholder="Super Hikcing Experience">
                                </div> 
                                <div class="form-group">
                                  <label for="fname">Story Category</label> 
                                  <select class="form-control" name="category" id="">
                                    <option selected value="<?php echo e($story->category_id); ?>"><?php echo e($story->cat_name); ?></option>
                                    <optgroup label="Other countries">
                                      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </optgroup>
                                  </select>
                                </div>
                                <div class="form-group">
                                  <label for="fname">Select Location</label> 
                                  <select class="form-control" name="location" id="">
                                    <option selected value="<?php echo e($story->location_id); ?>"><?php echo e($story->loca_country); ?></option>
                                    <optgroup label="Other countries">
                                      <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($location->country); ?>"><?php echo e($location->country); ?></option>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </optgroup>
                                  </select>
                                </div>
                                <div class="form-group">
                                    <label for="fname">Main Story</label>
                                    <textarea  class="form-control" id="storyEditor<?php echo e($story->id); ?>" rows="50" cols="40" name="story">
                                      <?php echo e($story->story); ?>

                                    </textarea>
                                    <script>
                                        // Replace the <textarea id="editor1"> with a CKEditor
                                        // instance, using default configuration.
                                        CKEDITOR.replace( 'storyEditor<?php echo e($story->id); ?>');
                                    </script>   
                                </div>
                                <div class="form-group">
                                  <?php if($story->image != null): ?>
                                    <label for="image_preview">Image preview</label><br>
                                    <img style="width:100%; height: 400%;" src="<?php echo e('/storage/'.$story->image); ?>" alt="">
                                  <?php else: ?>
                                    <p>No image available </p>
                                  <?php endif; ?>
                                </div>
                                <div class="form-group">
                                  <label for="featured_image">Featured Image</label>
                                  <input class="form-control" type="file" name="featured_image" >  
                                </div> 
                                <div class="modal-footer justify-content-between">
                                  <input hidden type="text" name="is_draft" value="1">
                                  <button type="button" class="btn btn-default" data-dismiss="modal">close</button>
                                  <button type="submit" class="btn btn-primary">Send for review</button>
                                </div>
                            </form>
                          <?php endif; ?>
                          
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <p class="text-center">You have no stories yet, create one today!</p>
              <?php endif; ?>
            </div>
          </div>

        </div>    
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\afrib-design\resources\views/account/stories.blade.php ENDPATH**/ ?>